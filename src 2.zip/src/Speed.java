import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.event.ActionEvent;


public class Speed extends JDialog {
    public JLabel speedLable;
    public JTextField speedtext;
    public JButton equals;
    public JLabel distance;
    public JLabel distanceInput;
    public JButton equalsforspeed;
    public JLabel time;
    public JTextField timeInput;




    public Speed(JFrame frame){
        super(frame, "Speed", true);
        setLayout(new FlowLayout());
        JLabel speedLable=new JLabel("Speed");
        speedLable.setSize(3,3);
        speedLable.setLocation(3,3);
        add(speedLable);
        JTextField speedtext=new JTextField("   ");
        speedtext.setBounds(50,10, 20,30);
        speedtext.setLocation(1,1);
        add(speedtext);
        JButton equalsforspeed=new JButton("=");
        add(equalsforspeed);
        JLabel time=new JLabel("time");
        add(time);
        JTextField timeInput=new JTextField("   ");
        timeInput.setBounds(12,12,12,12);
        add(timeInput);
        JLabel distance=new JLabel("distance");
        add(distance);
        JTextField distanceInput=new JTextField("   "); //textfield
        add(distanceInput);

        equalsforspeed.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (speedtext.getText().isEmpty()){
                    String forumal= String.valueOf(Double.parseDouble(distanceInput.getText())/Double.parseDouble(timeInput.getText()));
                    speedtext.setText(forumal);

                }
                else if(timeInput.getText().isEmpty()){
                    String forumal= String.valueOf(Double.parseDouble(distanceInput.getText())/Double.parseDouble(speedtext.getText()));
                    timeInput.setText(forumal);
                }
                else if(distanceInput.getText().isEmpty()){
                    String forumal=String.valueOf(Double.parseDouble(timeInput.getText())*Double.parseDouble(speedtext.getText()));
                    distanceInput.setText(forumal);
                }

            }
        });




    }

}