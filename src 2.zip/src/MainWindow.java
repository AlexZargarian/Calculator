

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class MainWindow extends JFrame {

    //Adding the menu bar, menu and menu items
    JMenuBar menubar;

    JMenu equation;
    JMenuItem distance;
    JMenuItem speed;
    JMenuItem quadraticEquation;

    JMenuItem spring;
    JMenuItem liner;

    private JPanel panel1;
    private JButton Speed;
    private JTextField velocityfiled;
    private JLabel time;
    private JTextField timefiled;
    private JLabel speedvariable;
    private JTextField textField1;
    private JButton disancelable;
    private JTextField distancefiled;
    private JTextField speedfiled;
    private JButton equals;


    private double total1 = 0.0;
    // for result
    private double total2 = 0.0;
    private int math_operator;

    JPanel JavaCalculator;
    private JTextField textField2;
    private JButton btnMore;
    private JButton btnMultiply;
    private JButton btn9;
    private JButton btn5;
    private JButton btn2;
    JButton btnpoint;
    private JButton btnAddition;
    private JButton btn6;
    private JButton btn3;
    private JButton btnClear;
    private JButton btnminus;
    private JButton btndevide;
    private JButton btnIntegral;
    private JButton btnEquals;
    private JButton btn7;
    private JButton btn4;
    private JButton btn1;
    private JButton btn0;
    private JButton btn8;


    public MainWindow() {

        this.setLayout(new GridLayout(5, 5));

        menubar = new JMenuBar(); //initializing
        this.add(menubar);

        equation = new JMenu("Equation"); //initializing
        menubar.add(equation);

        distance = new JMenuItem("Distance"); //initializing
        equation.add(distance);

        speed = new JMenuItem("Speed"); //initializing
        equation.add(speed);
        quadraticEquation = new JMenuItem("Quadratic equation"); //initializing
        equation.add(quadraticEquation);
        spring = new JMenuItem("Spring"); //initializing
        equation.add(spring);
        textField2 = new JTextField();
        textField2.setBounds(30, 30, 30, 30);
        btn1 = new JButton("1");
        btn2 = new JButton("2");
        btn3 = new JButton("3");
        btn4 = new JButton("4");
        btn5 = new JButton("5");
        btn6 = new JButton("6");
        btn7 = new JButton("7");
        btn8 = new JButton("8");
        btn9 = new JButton("9");
        btn0 = new JButton("0");
        btnAddition = new JButton("+");
        btnminus = new JButton("-");
        btndevide = new JButton("/");
        btnMultiply = new JButton("*");
        btnpoint = new JButton(".");
        btnEquals = new JButton("=");
        btnClear = new JButton("clear");


        this.add(textField2);
        this.add(btn1);
        this.add(btn2);
        this.add(btn3);
        this.add(btn4);
        this.add(btn5);
        this.add(btn6);
        this.add(btn7);
        this.add(btn8);
        this.add(btn9);
        this.add(btn0);
        this.add(btnAddition);
        this.add(btnminus);
        this.add(btndevide);
        this.add(btndevide);
        this.add(btnMultiply);
        this.add(btnpoint);
        this.add(btnClear);
        this.add(btnEquals);


        // setting the menu bar
        setJMenuBar(menubar);

        //Adding event listener to respond when clicked
        eventDistance e = new eventDistance();
        distance.addActionListener(e);

        eventSpeed e1 = new eventSpeed();
        speed.addActionListener(e1);

        eventQuadratic e2 = new eventQuadratic();
        quadraticEquation.addActionListener(e2);


        eventSpring e3 = new eventSpring();
        spring.addActionListener(e3);

        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn1text = textField2.getText() + btn1.getText();
                textField2.setText(btn1text);
            }
        });

        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn2text = textField2.getText() + btn2.getText();
                textField2.setText(btn2text);
            }
        });
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn3text = textField2.getText() + btn3.getText();
                textField2.setText(btn3text);
            }
        });
        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn4text = textField2.getText() + btn4.getText();
                textField2.setText(btn4text);
            }
        });
        btn5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn5text = textField2.getText() + btn5.getText();
                textField2.setText(btn5text);
            }
        });
        btn6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn6text = textField2.getText() + btn6.getText();
                textField2.setText(btn6text);
            }
        });
        btn7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn7text = textField2.getText() + btn7.getText();
                textField2.setText(btn7text);
            }
        });
        btn8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn8text = textField2.getText() + btn8.getText();
                textField2.setText(btn8text);
            }
        });
        btn9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn9text = textField2.getText() + btn9.getText();
                textField2.setText(btn9text);
            }
        });
        btn0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String btn0text = textField2.getText() + btn0.getText();
                textField2.setText(btn0text);
            }
        });
        btnAddition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonText = btnAddition.getText();
                getOperation(buttonText);
            }
        });
        btnminus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttentext = btnminus.getText();
                getOperation(buttentext);

            }
        });
        btndevide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttonText = btndevide.getText();
                getOperation(buttonText);

            }
        });
        btnMultiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String buttenText = btndevide.getText();
                getOperation(buttenText);
            }
        });

        btnEquals.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (math_operator) {
                    case '+':
                        total2 = total1 + Double.parseDouble(textField2.getText());
                        break;
                    case '-':
                        total2 = total1 - Double.parseDouble(textField2.getText());
                        break;
                    case '*':
                        total2 = total1 * Double.parseDouble(textField2.getText());
                        break;
                    case '/':
                        total2 = total1 / Double.parseDouble(textField2.getText());
                }
                textField2.setText(Double.toString(total2));
                total1 = 0;
            }
        });

        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                total2 = 0;
                textField2.setText("");
            }
        });
        btnpoint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (textField2.getText().equals("")) {
                    textField2.setText("0.");
                } else if (textField2.getText().contains(".")) {
                    btnpoint.setEnabled(false);
                } else {
                    String btnPointText = textField2.getText() + btnpoint.getText();
                    textField2.setText(btnPointText);
                }
                btnpoint.setEnabled(true);

            }
        });


    }

    public void getOperation(String btnText) {
        math_operator = btnText.charAt(0);
        total1 = total1 + Double.parseDouble(textField2.getText());
        textField2.setText("");
    }


    public class eventDistance implements ActionListener {
        public void actionPerformed(ActionEvent e2) {
            Distance gui = new Distance(MainWindow.this);
            gui.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            gui.setSize(500, 500);
            gui.setLocation(300, 300);
            gui.setTitle("Distance");
            gui.setVisible(true);
        }
    }

    public class eventSpeed implements ActionListener {
        public void actionPerformed(ActionEvent e1) {
            Speed gui = new Speed(MainWindow.this);
            gui.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            gui.setSize(500, 500);
            gui.setLocation(300, 300);
            gui.setTitle("Speed");
            gui.setVisible(true);
        }
    }

    public class eventQuadratic implements ActionListener {
        public void actionPerformed(ActionEvent e1) {
            QuadraticEquation gui = new QuadraticEquation(MainWindow.this);
            gui.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            gui.setSize(500, 500);
            gui.setLocation(300, 300);
            gui.setTitle("Quadratic Equation");
            gui.setVisible(true);


        }

    }


    public class eventSpring implements ActionListener {
        public void actionPerformed(ActionEvent e1) {
            Spring gui = new Spring(MainWindow.this);
            gui.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            gui.setSize(500, 500);
            gui.setLocation(300, 300);
            gui.setTitle("Spring");
            gui.setVisible(true);


        }

    }

    public static void main(String args[]) {
        MainWindow gui = new MainWindow();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setSize(500, 500);
        gui.setVisible(true);
        gui.setTitle("Calculator");

    }
}