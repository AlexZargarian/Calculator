import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.event.*;


public class QuadraticEquation extends JDialog {
    public JButton btn1;
    public JLabel x2input;
    public JTextField t1;
    public JLabel xlable;
    public JTextField t2;
    public JButton equal;
    public JTextField result;

    public QuadraticEquation(JFrame frame){

        super(frame, "Quadratic Equation", true);

        setLayout(new FlowLayout());

        JLabel x2input=new JLabel("X2");
        add(x2input);
        JTextField t1 = new JTextField("   ");
        t1.setBounds(10,10, 200,30);
        add(t1);
        JLabel xlable=new JLabel("X");
        xlable.setLocation(20,20);
        add(xlable);
        JTextField t2 = new JTextField("   ");
        t2.setBounds(30,30, 200,30);
        add(t2);
        JLabel constant=new JLabel("Constant");
        constant.setLocation(40,40);
        add(constant);
        JTextField t3 = new JTextField("   ");
        t3.setBounds(300,200, 20,30);
        t3.setLocation(60,60);
        add(t3);
        JButton equal=new JButton("=");
        add(equal);
        JTextField result= new JTextField("   ");
        result.setLocation(300,330);
        add(result);

        equal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double a= Double.parseDouble(t1.getText());
                double b=Double.parseDouble(t2.getText());
                double c=Double.parseDouble(t3.getText());
                double delta= ((b*b)-(4*a*c));
                if (a==0){
                    result.setText(String.valueOf((-c)/b)); ;
                }
                else if (delta==0){
                    result.setText(String.valueOf((-b)/(2*a)));
                }
                else if (delta<0){
                    result.setText(String.valueOf("No real root"));
                }
                else{
                    double root1=((-b+Math.sqrt(delta))/(2*a));
                    double root2=((-b-Math.sqrt(delta))/(2*a));
                    result.setText(String.valueOf(root1+ ", "+root2));
                }
            }
        });

    }


}