import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class Distance extends JDialog {
    public JLabel x2;
    public JTextField x2input;
    public JLabel x1;
    public JTextField x1input;
    public JLabel y2;
    public JTextField y2input;
    public JLabel y1;
    public JTextField y1input;
    public JButton equal;



    public Distance(JFrame frame){
        super(frame, "distance", true);
        setLayout(new FlowLayout());

        JLabel x2=new JLabel("x2");
        add(x2);
        JTextField x2input=new JTextField("   ");
        add(x2input);
        JLabel x1=new JLabel("x1");
        add(x1);
        JTextField x1input=new JTextField("   ");
        add(x1input);
        JLabel y2=new JLabel("y2");
        add(y2);
        JTextField y2input=new JTextField("   ");
        add(y2input);
        JLabel y1=new JLabel("y1");
        add(y1);
        JTextField y1input=new JTextField("   ");
        add(y1input);
        JButton equal= new JButton("=");
        add(equal);
        JTextField resultforDistance=new JTextField("        ");
        add(resultforDistance);



        equal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double x1= Double.parseDouble(x1input.getText());
                double x2= Double.parseDouble(x2input.getText());
                double minusX=Math.pow(x1-x2,2);
                double y1= Double.parseDouble(y1input.getText());
                double y2= Double.parseDouble(y2input.getText());
                double minusY=Math.pow(y1-y2,2);
                double result= Math.sqrt(minusX+minusY);
                resultforDistance.setText(Double.toString(result));

            }
        });



    }
}